<?= $this->include('admin/partial/header') ?>
<?= $this->include('admin/partial/sidebar') ?>

<div class="main-content">
  <section class="section">
    <div class="section-header">
      <h1><i class="fas fa-users"></i> Data Transaksi</h1>
    </div>
    <div class="section-body">
      <table id="example" class="display" style="width:100%">
        <thead>
          <tr>
            <th>No</th>
            <th>Name</th>
            <th>Email</th>
            <th>Type Subscribtion</th>
            <th>Gross Ammount</th>
            <th>Status Transaction</th>
            <th>Created At</th>
            <th>Updated At</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th>01</th>
            <th>Oki</th>
            <th>Oki@gmail.com</th>
            <th>Basic</th>
            <th>Rp 150.000</th>
            <th>Proses</th>
            <th>2023-12-12 12:50</th>
            <th>2023-12-12 12:50</th>
          </tr>
          <tr>
            <th>02</th>
            <th>Aji</th>
            <th>admin judi togel</th>
            <th>Aji</th>
            <th>Depo</th>
            <th>1</th>
            <th>Rp 150.000</th>
            <th>Today</th>
          </tr>
          <tr>
            <th>03</th>
            <th>Vicky</th>
            <th>admin judi togel</th>
            <th>Vicky</th>
            <th>Depo</th>
            <th>1</th>
            <th>Rp 150.000</th>
            <th>Today</th>
          </tr>
          <tr>
            <th>04</th>
            <th>Imanda</th>
            <th>admin judi togel</th>
            <th>Imanda</th>
            <th>Depo</th>
            <th>1</th>
            <th>Rp 150.000</th>
            <th>Today</th>
          </tr>
          <tr>
            <th>05</th>
            <th>Roji</th>
            <th>admin judi togel</th>
            <th>Roji</th>
            <th>Depo</th>
            <th>1</th>
            <th>Rp 150.000</th>
            <th>Today</th>
          </tr>
          <tr>
            <th>06</th>
            <th>Robeth</th>
            <th>admin judi togel</th>
            <th>Robeth</th>
            <th>Depo</th>
            <th>1</th>
            <th>Rp 150.000</th>
            <th>Today</th>
          </tr>
          <tr>
            <th>07</th>
            <th>Abel</th>
            <th>admin judi togel</th>
            <th>Abel</th>
            <th>Depo</th>
            <th>1</th>
            <th>Rp 150.000</th>
            <th>Today</th>
          </tr>
          <tr>
            <th>08</th>
            <th>Cina</th>
            <th>admin judi togel</th>
            <th>Cina</th>
            <th>Depo</th>
            <th>1</th>
            <th>Rp 150.000</th>
            <th>Today</th>
          </tr>
          <tr>
            <th>09</th>
            <th>Albert</th>
            <th>admin judi togel</th>
            <th>Albert</th>
            <th>Depo</th>
            <th>1</th>
            <th>Rp 150.000</th>
            <th>Today</th>
          </tr>
          <tr>
            <th>10</th>
            <th>Wibu</th>
            <th>admin judi togel</th>
            <th>Wibu</th>
            <th>Depo</th>
            <th>1</th>
            <th>Rp 150.000</th>
            <th>Today</th>
          </tr>
          <tr>
            <th>11</th>
            <th>Nabil</th>
            <th>admin judi togel</th>
            <th>Nabil</th>
            <th>Depo</th>
            <th>1</th>
            <th>Rp 150.000</th>
            <th>Today</th>
          </tr>
          <tr>
            <th>12</th>
            <th>Oki</th>
            <th>admin judi togel</th>
            <th>oki</th>
            <th>Depo</th>
            <th>1</th>
            <th>Rp 150.000</th>
            <th>Today</th>
          </tr>
          <tr>
            <th>13</th>
            <th>Oki</th>
            <th>admin judi togel</th>
            <th>oki</th>
            <th>Depo</th>
            <th>1</th>
            <th>Rp 150.000</th>
            <th>Today</th>
          </tr>
          <tr>
            <th>14</th>
            <th>Oki</th>
            <th>admin judi togel</th>
            <th>oki</th>
            <th>Depo</th>
            <th>1</th>
            <th>Rp 150.000</th>
            <th>Today</th>
          </tr>
          <tr>
            <th>15</th>
            <th>Oki</th>
            <th>admin judi togel</th>
            <th>oki</th>
            <th>Depo</th>
            <th>1</th>
            <th>Rp 150.000</th>
            <th>Today</th>
          </tr>
          <tr>
            <th>16</th>
            <th>Oki</th>
            <th>admin judi togel</th>
            <th>oki</th>
            <th>Depo</th>
            <th>1</th>
            <th>Rp 150.000</th>
            <th>Today</th>
          </tr>
          <tr>
            <th>17</th>
            <th>Oki</th>
            <th>admin judi togel</th>
            <th>oki</th>
            <th>Depo</th>
            <th>1</th>
            <th>Rp 150.000</th>
            <th>Today</th>
          </tr>
          <tr>
            <th>18</th>
            <th>Oki</th>
            <th>admin judi togel</th>
            <th>oki</th>
            <th>Depo</th>
            <th>1</th>
            <th>Rp 150.000</th>
            <th>Today</th>
          </tr>
          <tr>
            <th>19</th>
            <th>Oki</th>
            <th>admin judi togel</th>
            <th>oki</th>
            <th>Depo</th>
            <th>1</th>
            <th>Rp 150.000</th>
            <th>Today</th>
          </tr>
          <tr>
            <th>20</th>
            <th>Oki</th>
            <th>admin judi togel</th>
            <th>oki</th>
            <th>Depo</th>
            <th>1</th>
            <th>Rp 150.000</th>
            <th>Today</th>
          </tr>
          <!-- DataTable On Progress, Note : Node.js Requirement-->
        </tbody>
      </table>
    </div>
  </section>

</div>

<?= $this->include('admin/partial/footer') ?>